﻿import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info(f"AllSenses received: {json.dumps(event)}")
    
    try:
        # Parse input
        if 'body' in event:
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        else:
            body = event
        
        # Simple threat analysis for demo
        audio_data = body.get('audioData', body.get('message', 'No data'))
        threat_level = 'NONE'
        
        # Basic keyword detection
        if any(word in str(audio_data).upper() for word in ['HELP', 'EMERGENCY', 'DANGER']):
            threat_level = 'HIGH'
        elif any(word in str(audio_data).upper() for word in ['SCARED', 'WORRIED']):
            threat_level = 'MEDIUM'
        
        response_data = {
            'status': 'success',
            'message': 'AllSenses AI Guardian is live and working!',
            'threatLevel': threat_level,
            'audioData': audio_data,
            'timestamp': context.aws_request_id,
            'version': '1.0'
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST,OPTIONS,GET',
                'Content-Type': 'application/json'
            },
            'body': json.dumps(response_data)
        }
        
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'status': 'error',
                'message': str(e)
            })
        }
