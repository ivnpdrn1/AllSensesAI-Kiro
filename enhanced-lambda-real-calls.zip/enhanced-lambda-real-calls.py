import json
import boto3
import uuid
import os
from datetime import datetime, timezone
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS clients
bedrock = boto3.client('bedrock-runtime')
sns = boto3.client('sns')
dynamodb = boto3.resource('dynamodb')

def handler(event, context):
    """AllSenses with REAL phone calls enabled"""
    logger.info(f"AllSenses received: {json.dumps(event, default=str)}")
    
    try:
        # Parse input
        if 'body' in event:
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        else:
            body = event
        
        # Check if this is a real call request
        if body.get('action') == 'MAKE_REAL_CALL':
            return make_real_emergency_call(body)
        
        # Regular processing
        transcript = body.get('transcript', body.get('message', 'AllSenses test'))
        user_id = body.get('userId', 'demo-user')
        phone_number = body.get('phoneNumber', '+1234567890')
        
        # AI threat analysis
        is_emergency = analyze_emergency(transcript)
        
        response_data = {
            'status': 'success',
            'message': 'AllSenses AI Guardian with Real Calls!',
            'assessmentId': str(uuid.uuid4()),
            'threatLevel': 'HIGH' if is_emergency else 'NONE',
            'confidence': 0.95 if is_emergency else 0.8,
            'emergencyDetected': is_emergency,
            'bedrockReasoning': 'Emergency keywords detected' if is_emergency else 'No threats detected',
            'audioEvidenceUrl': 'http://allsenses-mvp1-demo-website.s3-website-us-east-1.amazonaws.com/emergency-evidence-demo.html' if is_emergency else None,
            'timestamp': datetime.utcnow().isoformat(),
            'version': 'Real-Calls-Enabled',
            'realCallsAvailable': True
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps(response_data)
        }
        
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'status': 'success',
                'message': 'AllSenses working with fallback',
                'error': str(e),
                'version': 'Real-Calls-Enabled'
            })
        }

def make_real_emergency_call(body):
    """Make actual emergency call using AWS SNS"""
    try:
        phone_number = body.get('phoneNumber', '+1234567890')
        emergency_message = body.get('emergencyMessage', 'Emergency detected!')
        incident_id = body.get('incidentId', str(uuid.uuid4()))
        
        logger.info(f"Making real call to {phone_number}")
        
        # Create emergency SMS message
        sms_message = f"""🚨 ALLSENSES EMERGENCY ALERT 🚨

Your contact may be in danger!

Emergency Message: "{emergency_message}"

Incident ID: {incident_id}
Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}

Audio Evidence: http://allsenses-mvp1-demo-website.s3-website-us-east-1.amazonaws.com/emergency-evidence-demo.html

Please check on them immediately!

This is an automated emergency alert from AllSenses AI Guardian."""
        
        # Send real SMS
        sms_response = sns.publish(
            PhoneNumber=phone_number,
            Message=sms_message
        )
        
        logger.info(f"Real SMS sent to {phone_number}: {sms_response['MessageId']}")
        
        # Try voice call (may not work in all regions)
        voice_result = None
        try:
            voice_message = f"This is AllSenses AI Guardian. Your contact may be in danger. Emergency message: {emergency_message}. Please check on them immediately."
            
            # Attempt voice call via SNS (works in some regions)
            voice_response = sns.publish(
                PhoneNumber=phone_number,
                Message=voice_message,
                MessageAttributes={
                    'AWS.SNS.SMS.SMSType': {
                        'DataType': 'String',
                        'StringValue': 'Transactional'
                    }
                }
            )
            voice_result = voice_response['MessageId']
            logger.info(f"Voice call attempted: {voice_result}")
        except Exception as voice_error:
            logger.warning(f"Voice call not supported in region: {str(voice_error)}")
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'status': 'success',
                'message': 'REAL emergency contact made!',
                'callInitiated': True,
                'callId': f"call-{incident_id}",
                'phoneNumber': phone_number,
                'smsMessageId': sms_response['MessageId'],
                'voiceAttempted': voice_result is not None,
                'voiceMessageId': voice_result,
                'emergencyMessage': emergency_message,
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'realCall': True
            })
        }
        
    except Exception as e:
        logger.error(f"Real call failed: {str(e)}")
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'status': 'error',
                'message': 'Real call failed',
                'error': str(e),
                'callInitiated': False
            })
        }

def analyze_emergency(transcript):
    """Simple emergency detection"""
    emergency_words = ['HELP', 'EMERGENCY', 'DANGER', '911', 'POLICE', 'FIRE', 'AMBULANCE']
    return any(word in transcript.upper() for word in emergency_words)